$("#js-icon").on('click', () => {
  $("main").addClass("background-white")
})
