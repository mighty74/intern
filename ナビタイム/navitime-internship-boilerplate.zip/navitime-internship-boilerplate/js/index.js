(() => {
  window.addEventListener("load", () => {
    new navitime.geo.Map(
      "map",
      new navitime.geo.LatLng("35.689614", "139.691634"),
      15
    );
  });
})();
