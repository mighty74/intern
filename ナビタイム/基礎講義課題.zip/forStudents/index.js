/* TODO: JavaScript課題
①index.jsをindex.htmlで読みこみ、alertが表示されることを確認しなさい
②画像をクリックしたら背景色が白色になるようにjQueryで実装しなさい

*/

alert('index.jsの読み込みに成功しました！');