$(document).ready(function() {	
    $("#text").text('Hello World!');
});