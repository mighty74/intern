document.getElementById('search').addEventListener('click', function(){
    const searchWord = document.getElementById('search-window').value;
    alert(searchWord);
})