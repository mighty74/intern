let count = 0;
function clickEvent() {
    // この下の行にブレークポイントをつくりましょう //
    count++;
    console.log("クリック回数：" + count);
    alert("デバッグ練習");
}